# mypackage
This library was created as an example to publish your own Python package

# how to install

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/AyandaNdlovu12/mypackage.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/AyandaNdlovu12/mypackage.git`